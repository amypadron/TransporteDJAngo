import { Injectable } from '@angular/core';
import { Trabajador } from '../interface/trabajador';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TrabajadorService {

  servidor = "http://localhost:3000/api";


  cargar_trabajador(){

    return this.ConsultarTrabajadores();
  }
  constructor(private servicio:HttpClient) { }

  eliminar_trabajador(id: string){
    return this.servicio.delete(`${this.servidor}/trabajador/deleteTrabajador/${id}`);
  }

  ConsultarTrabajadores(): Observable<any>{
    return this.servicio.get(`${this.servidor}/trabajador`);
  }

  agregarTrabajador(trabajador: Trabajador){
    return this.servicio.post(`${this.servidor}/trabajador/createTrabajador`, trabajador);
  }

  modificarTrabajador(trabajador: Trabajador){
    console.log(trabajador.id);
    return this.servicio.post(`${this.servidor}/trabajador/updateTrabajador/${trabajador.id}`, trabajador);
  }

  cargarTrabajador(id: string) {
    return this.servicio.get<Trabajador>(`${this.servidor}/trabajador/${id}`).pipe(
      map(r => ({
        id: r.id,
        ci: r.ci,
        sexo: r.sexo,
        telefono: r.telefono,
        direccion_particular: r.direccion_particular,
        nombre: r.nombre,
        anios_experiencia: r.anios_experiencia,
        nivel_escolar: r.nivel_escolar,
        salario_basico: r.salario_basico,

      }))
    );
  }

  }



