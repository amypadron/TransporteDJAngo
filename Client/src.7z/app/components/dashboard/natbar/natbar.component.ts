import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-natbar',
  templateUrl: './natbar.component.html',
  styleUrls: ['./natbar.component.scss']
})
export class NatbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
