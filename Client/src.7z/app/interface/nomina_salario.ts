export interface Nomina {
  id: string;
  cantidad_dias: number;
  salario: number;
  mes: Date;
}
