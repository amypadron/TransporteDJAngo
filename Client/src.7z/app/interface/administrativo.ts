export interface Administativo{
  id: string;
cargo: string;
}
