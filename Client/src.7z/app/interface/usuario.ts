export interface Usuario{
  id: string;
  usuario: string;
  pasword: string;
}
