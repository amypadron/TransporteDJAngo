export interface Viaje{
  id: string;
  carga_transportada: number;
  km_recorrido: number;
  dia_semana: Date;
  provincias_recorridas: number;
  dia_regreso: Date;
}
