export interface Chofer{
  id: string;
  tipo: string;
  cantidad_viajes: number;
  evaluacion_mensual: number;
  
}
