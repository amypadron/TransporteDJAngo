export interface Camion{
  id: string;
  chapa: string;
  marca: string;
  anio_fabricacion: number;
  cantidad_reparaciones: number;
  gasto_km: string;
}
