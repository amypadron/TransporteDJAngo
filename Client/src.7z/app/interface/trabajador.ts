export interface Trabajador{
  id: string;
  ci: string;
  sexo: string;
  telefono: string;
  direccion_particular: string;
  nombre: string;
  anios_experiencia: number;
  nivel_escolar: string;
  salario_basico: number;
  chofer: object;
  administrativo: object;
}

